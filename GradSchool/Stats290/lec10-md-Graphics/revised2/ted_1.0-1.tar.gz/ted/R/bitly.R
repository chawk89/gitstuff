#' The bitly dataset (you should really document this better!)
#'
#' @name bitly
#' @docType data
#' @keywords data
#'
NULL

