#' ted is a simple package with one function
#'
#' @name ted-package
#' @aliases ted-package ted
#' @docType package
#' @author Ted Cat
#' @keywords package
NULL



