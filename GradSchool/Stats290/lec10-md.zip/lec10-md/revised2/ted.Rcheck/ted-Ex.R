pkgname <- "ted"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('ted')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("hello")
### * hello

flush(stderr()); flush(stdout())

### Name: hello
### Title: A simple greeting function
### Aliases: hello

### ** Examples

  hello()
  hello("and goodbye")



cleanEx()
nameEx("simple_plot")
### * simple_plot

flush(stderr()); flush(stdout())

### Name: simple_plot
### Title: A simple scatterplot using ggplot2
### Aliases: simple_plot

### ** Examples

simple_plot(mtcars$wt, mtcars$mpg)



### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
