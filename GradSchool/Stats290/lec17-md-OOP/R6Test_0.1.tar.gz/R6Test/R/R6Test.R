#' R6Test: A Test package for R6
#'
#' \code{R6Test} provides a \code{Stock} object that can store stock symbols and prices.
#'
#' @section Introduction:
#'
#' Stock is a simple package for encapsulating stocks.
#'
#' @section Detail:
#'
#' \code{R6Test} allows you to set stock object symbol and data and to plot.
#'
#'
#' @examples
#' s <- Stock$new()
#' s$getSymbol()
#' s$getData()
#' s$plot()
#' @docType package
#' @name R6Test
NULL


