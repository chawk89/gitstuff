#' Create a \code{Stock} object with data or random data (default)
#'
#' @description \code{Stock} is an object that encapsulates stocks.
#' A stock consists of a symbol of (scalar) type \code{character}
#' and data consists of a two-column data frame with variables named
#' \code{price} and \code{date}, of types \code{numeric} and {Date}
#' respectively.
#'
#' @docType class
#' @importFrom R6 R6Class
#'
#' @export
Stock <- R6::R6Class("Stock",
                     private = list(symbol = NA,
                                    data = NA,
                                    valid = function(symbol, data) {
                                        if (!is.data.frame(data) || nrow(data) < 2) {
                                            return(FALSE)
                                        }
                                        dfNames <- sort(names(data))
                                        expectedNames <- c("date", "price")
                                        if (length(expectedNames) != length(dfNames) ||
                                            !all.equal(expectedNames, dfNames)) {
                                            return(FALSE)
                                        }

                                        if (length(symbol) == 0 || nchar(symbol) == 0) {
                                            return(FALSE)
                                        }
                                        TRUE
                                    }),
                     public = list(
                         #' @field comment a comment string
                         comment = "",

                         #' @description
                         #' Create a new Stock object.
                         #' @param symbol a stock symbol string, default `JUNK`
                         #' @param comment a comment string
                         #' @param data a data frame of prices and dates for the stock
                         #' @return A new `Stock` object.
                         #' @importFrom stats rnorm
                         initialize = function(symbol = "JUNK",
                                               comment = "junk stock",
                                               data = data.frame(price = stats::rnorm(10, mean = 100, sd = 5),
                                                                 date = as.Date(Sys.Date()) - 1:10)) {
                             if (!private$valid(symbol, data)) {
                                 stop("Bad input values")
                             }
                             private$symbol <- symbol
                             self$comment  <- comment
                             private$data <- data
                         },
                         #' @description
                         #' Print the stock.
                         #' @examples
                         #' s <- Stock$new()
                         #' print(s)
                         print = function() {
                             ## Have to use private$ for even our own private stuff
                             cat(sprintf("Stock Symbol: %s\n", private$symbol))
                             cat(sprintf("Comment: %s\n", self$comment))
                             ## Have to use self$ for public stuff
                             str(self$getData())
                         },

                         #' @description
                         #' Return the stock symbol.
                         #' @examples
                         #' s <- Stock$new()
                         #' s$getSymbol()
                         getSymbol = function() private$symbol,

                         #' @description
                         #' Set the stock symbol.
                         #' @param symbol the stock symbol
                         #' @examples
                         #' s <- Stock$new()
                         #' s$setSymbol("JUNK2")
                         #' s$getSymbol()
                         setSymbol = function(symbol) {
                             if (!private$valid(symbol, private$data)) {
                                 stop("Bad symbol!")
                             }
                             private$symbol <- symbol
                         },

                         #' @description
                         #' Return the data frame for the stock
                         #' @examples
                         #' s <- Stock$new()
                         #' s$getData()
                         getData = function() private$data,

                         #' @description
                         #' Set the data frame for the stock
                         #' @param data the data frame for the stock
                         #' @examples
                         #' s <- Stock$new()
                         #' s$setData(data.frame(price = stats::rnorm(10, mean = 200, sd = 5),
                         #'                                   date = as.Date(Sys.Date()) - 1:10))
                         setData = function(data) {
                             if (!private$valid(private$symbol, data)) {
                                 stop("Bad data!")
                             }
                             private$data <- data
                         },

                         #' @description
                         #' Plot the stock price versus date
                         #' @examples
                         #' if (requireNamespace("quantmod", quietly = TRUE)) {
                         #'   ## Pick up Apple stock
                         #'   aapl <- as.data.frame(quantmod::getSymbols("AAPL", env = NULL))
                         #'   aapl <- data.frame(date = as.Date(rownames(aapl)), price = aapl$AAPL.Close)
                         #'   stockEx <- Stock$new(symbol = "AAPL", data = aapl)
                         #'   stockEx$comment <- "Apple Stock Prices"
                         #' } else {
                         #'   ## Construct another junk stock
                         #'   stockEx <- Stock$new(symbol = "JNK2",
                         #'                 data = data.frame(price = stats::rnorm(10, mean = 200, sd = 5),
                         #'                                   date = as.Date(Sys.Date()) - 1:10))
                         #' }
                         #'
                         #' stockEx
                         #' stockEx$plot()
                         #' @importFrom ggplot2 qplot
                         plot = function() {
                             ggplot2::qplot(date, price, data = private$data,
                                            main = sprintf("Stock Symbol: %s", private$symbol),
                                            geom = "line")
                         })
                     )
