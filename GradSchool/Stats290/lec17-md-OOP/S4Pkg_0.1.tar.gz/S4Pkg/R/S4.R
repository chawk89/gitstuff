#' Stock: Objects for representing stocks
#'
#' @description A class to encapsulate a stock with a symbol
#'
#' @name Stock-class
#' @import methods
#' @importFrom stats rnorm
#' @docType class
#'
#' @exportClass Stock
#'
#' @slot symbol a character string
#' @slot data a two-column data frame of at least 2 rows with
#' variable names \code{price} and \code{date} of type \code{Date}.
#'
#' @section Details:
#'
#' Objects of class \code{Stock} can be created by calls of the form
#' \code{new("Stock", ...)}.  The optional arguments can include
#' stock symbol (\code{symbol}) and price data (\code{data}) as a
#' two-column data frame with columns named \code{date} and
#' \code{price}. If unspecified, a stock with symbol \code{JUNK}
#' and random data is created.

#' @examples
#'
#' showClass("Stock")
#'
#' ##
#' ## Construct a default stock object
#' ##
#' junk <- new("Stock")
#' junk
#' if (requireNamespace("quantmod", quietly = TRUE)) {
#'   ## Pick up Apple stock
#'   aapl <- as.data.frame(quantmod::getSymbols("AAPL", env = NULL))
#'   aapl <- data.frame(date = as.Date(rownames(aapl)), price = aapl$AAPL.Close)
#'   stockEx <- new("Stock", symbol = "AAPL", data = aapl)
#' } else {
#'   ## Construct another junk stock
#'   stockEx <- new("Stock", symbol = "JNK2",
#'                 data = data.frame(price = stats::rnorm(10, mean = 200, sd = 5),
#'                                   date = as.Date(Sys.Date()) - 1:10))
#' }
#' plot(stockEx)
#'
setClass("Stock", representation(symbol = "character",
                                 data = "data.frame"),
         prototype = prototype (
             symbol = "JUNK",
             data = data.frame(price = stats::rnorm(10, mean = 100, sd = 5),
                               date = as.Date(Sys.Date()) - 1:10))
         )

#'
#' Stock class constructor function
#'
#' @param symbol a character string
#' @param data a two-column data frame of at least 2 rows with
#' variable names \code{price} and \code{date} of type \code{Date}.
#' @importFrom stats rnorm
#' @export
#' @examples
#'
#' junk <- new("Stock")
#' junk
#' if (requireNamespace("quantmod", quietly = TRUE)) {
#'   ## Pick up Apple stock
#'   aapl <- as.data.frame(quantmod::getSymbols("AAPL", env = NULL))
#'   aapl <- data.frame(date = as.Date(rownames(aapl)), price = aapl$AAPL.Close)
#'   stockEx <- new("Stock", symbol = "AAPL", data = aapl)
#' } else {
#'   ## Construct another junk stock
#'   stockEx <- new("Stock", symbol = "JNK2",
#'                 data = data.frame(price = stats::rnorm(10, mean = 200, sd = 5),
#'                                   date = as.Date(Sys.Date()) - 1:10))
#' }
#' plot(stockEx)
#'
Stock <- function(symbol = "JUNK",
                  data = data.frame(price = stats::rnorm(10, mean = 100, sd = 5),
                                    date = as.Date(Sys.Date()) - 1:10)) {
    ## Do other things if needed but return constructed object
    new("Stock", symbol = symbol, data = data)
}


#'
#' Stock class validity tester
#' @param object an object puportedly of class \code{Stock}
#' @return TRUE if valid, a character vector error messages if not
#' @keywords internal
#'
stockValidity <- function(object) {
    retVal <- NULL
    if (!is.data.frame(object@data)) {
        retVal <- c(retVal, "Data slot is not a data frame!")
    }
    if (nrow(object@data) < 2) {
        retVal <- c(retVal, "Data slot needs at least 2 rows!")
    }
    dfNames <- sort(names(object@data))
    expectedNames <- c("date", "price")
    if (length(expectedNames) != length(dfNames) ||
        !all.equal(expectedNames, dfNames)) {
        stop("Bad data frame columns in value")
    }

    if (!all.equal(dfNames, c("date", "price"))) {
        retVal <- c(retVal, "Names of data frame columns are incorrect!")
    }
    if (length(object@symbol) == 0 || nchar(object@symbol) == 0) {
        retVal <- c(retVal, "Bad Stock Symbol")
    }
    if (is.null(retVal))
        TRUE
    else
        retVal
}
setValidity("Stock", stockValidity)


#'
#' Stock class accessor and modifier functions for slot \code{symbol}, \code{data}
#' and a plot method
#' @param object the stock object
#' @param value the symbol value
#' @rdname Stock-class
#' @export
#'
setGeneric("getSymbol", function(object) standardGeneric("getSymbol") )

#' @docType methods
#' @rdname Stock-class
setMethod("getSymbol", "Stock", function(object) object@symbol )

#' @rdname Stock-class
#' @export
setGeneric("getData", function(object) standardGeneric("getData") )

#' @docType methods
#' @rdname Stock-class
setMethod("getData", "Stock", function(object) object@data )

#' @rdname Stock-class
#' @export
setGeneric("setSymbol<-", function(object, value) standardGeneric("setSymbol<-") )

#' @docType methods
#' @rdname Stock-class
setMethod(f = "setSymbol<-",
          signature = "Stock",
          definition = function(object, value) {
              object@symbol <- value
              validObject(object)
              object
          })

#' @rdname Stock-class
#' @export
setGeneric("setData<-", function(object, value) standardGeneric("setData<-") )

#' @docType methods
#' @rdname Stock-class
setMethod(f = "setData<-",
          signature = "Stock",
          definition = function(object, value) {
              object@data <- value
              validObject(object)
              object
          })

#' @rdname Stock-class
#' @export
setGeneric("plot", function(x, y, ...) standardGeneric("plot"))

#'
#' Stock class plot method
#' @param x the stock object
#' @param y ignored
#' @param ... other args passed to ggplot2::qplot
#' @return a ggplot object
#' @importFrom graphics plot
#' @importFrom ggplot2 qplot
#' @docType methods
#' @rdname Stock-class
#'
setMethod("plot", signature(x = "Stock", y = "missing"),
          function(x, y, ...) {
              data <- x@data
              ggplot2::qplot(date, price, data = data,
                             main = sprintf("Stock Symbol: %s", x@symbol),
                             geom = "line", ...)
          })


