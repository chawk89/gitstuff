
#' A test package with S4 classes in R
#'
#' @docType package
#' @import methods
#' @importFrom utils globalVariables
#' @name S4Pkg
NULL

## To fix up NOTEs in R CMD check
## Strictly speaking, date is not needed below,
## because it is exported by base package.
utils::globalVariables(names = c("date",
                                 "price"))
