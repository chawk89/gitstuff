#!/usr/bin/env Rscript
library(opencpu)
ocpu_start_server(port=8192)
