#' A test package with R
#'
#' A package illustrating global variables. See example for for
#' functions \code{link{closeEnough}}.
#' @docType package
#' @name testpack2
NULL
