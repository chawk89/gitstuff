library(testthat)
library(ted)

test_check("ted")
