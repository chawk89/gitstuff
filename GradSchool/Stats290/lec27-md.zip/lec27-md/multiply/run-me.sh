#!/bin/bash
sbatch script-1.sh
sbatch script-2.sh
sbatch script-3.sh
