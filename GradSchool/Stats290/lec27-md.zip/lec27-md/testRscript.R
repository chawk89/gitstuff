#!/usr/bin/env Rscript
set.seed(123)
print(rnorm(3))
