#!/usr/bin/env Rscript
args <- commandArgs()
print(args)
