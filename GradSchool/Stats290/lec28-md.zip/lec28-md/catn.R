##
## Cat function with \n at the end
##
catn <- function(...)
    cat(..., "\n")

